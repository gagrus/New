<template>


    <div v-if="userName">
      <div class="chat">
        <h2>Чат</h2>

        <div class="text" v-for="msg in messages" :key="msg.id">
          {{msg.user}}: {{msg.text}}
        </div>

        <div v-show="emptyMsg" class="empty">Сообщений нет</div>
      </div>
      <input v-model="newMessage" placeholder="Введите сообщение"/>
      <button @click="sendMessage">Отправить</button>
      <button @click="delMessage">Удалить</button>
    </div> 
    
    <div v-else class="alert">
        <router-link :to="{name: 'Home'}">Авторизуйтесь!</router-link>
    </div>
</template>

<script>
export default {
    name: 'ChatPage',
    data(){
      return {
        messages: [],
        newMessage: '',
        emptyMsg: true,
        userName: localStorage.getItem('userName'),
    }
    },
    computed(){
      localStorage.setItem('userName', this.$route.query.userName)
    },
    methods: {
      sendMessage(){
        if(this.newMessage !== ''){
          this.emptyMsg = false
          this.messages.push({id: new Date().getTime(), text: this.newMessage, user: this.userName})
          this.saveChatMessages()
          this.newMessage = ''
          console.log(this.messages)
        }
      },
      saveChatMessages(){
        const records = this.messages
        localStorage.setItem(`messages_${this.userName}`, JSON.stringify(records))
      },
      delMessage(){
        this.messages = []
        localStorage.removeItem(`messages_${this.userName}`, JSON.stringify(this.messages))

        this.emptyMsg = true
      },
      loadChatMessages(){
        const records = JSON.parse(localStorage.getItem(`messages_${this.userName}`))
        if(records){
          this.messages = records
          this.emptyMsg = false
        }
      }
    },
    created(){
      this.loadChatMessages()
    }
};

</script>
<style scoped>
h2 {
  color:darkorange
}

.text {
  margin-bottom: 10px;
  
}

.chat {
  width: 500px;
  height: 100%;
  border: 5px solid blanchedalmond;
  color: black;
  background-color:lightblue;
  font-weight: bold;
  justify-content: center;
  align-items: center;
  overflow: scroll;
  
}

</style>