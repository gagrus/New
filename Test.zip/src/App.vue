<template>
 <div class="container">
  <NavComp/>
  <router-view></router-view>
  <footer>
  <p>2023</p>
 </footer>
 </div>
 
</template>

<script>
import NavComp from './components/Navigation.vue'

export default {
  name: 'App',
  components: {
    NavComp
  }
}
</script>

<style>
.container{
  background-color:rgb(160, 148, 148);
  flex-direction: column;
  align-items: center;
  height: 1325px;
  font-family:Arial, Helvetica, sans-serif;
  display: flex;
}
</style>
