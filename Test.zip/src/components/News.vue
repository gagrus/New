<!-- <template>
<div class="cont">
    <div class="search">
       <form action="">
          <input type="text" placeholder="search">
       </form>
       <div class="search-imgs">
         <i class="fast-search"></i>
         <i class="fast-times"></i>
       </div>
    </div>
    <div class="results">

    </div>
</div>
</template>

<script>
export default {
    props: [
        'apiKey'
    ],
    data: () => {
        return {
          apiUrl: '',
          isB
        }
    }
}
</script>

<style scoped>
.cont {
    position: relative;
}

.search{
    position:relative;
    width: 100%;
    height: 50px;
    font-size: 1.5rem;
}

.input {
    width: calc(100% - 120px);
    height: 60px;
    margin: 0;
    border: none;

    &:focus {
        outline: none;
}

.search-icons {

}
}

</style> -->