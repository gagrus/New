<template>
    <div class="container">
      <nav>
        <router-link to="/">Домашняя страница</router-link>
        <router-link to="/calc">Калькулятор</router-link>
        <router-link to="/test">API</router-link>
        <router-link to="/chat">В чат</router-link>
      </nav>
    </div>
</template>

<script>
export default {
    name: 'NavComp'
}
</script>

<style scoped>
.container{
    background-color: rgb(65, 66, 64);
    font-family: fantasy;
    height: 70px;
    width: 100%;
    display: flex;
    justify-content: center;
}

nav{
    width: 500px;
    height: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
</style>