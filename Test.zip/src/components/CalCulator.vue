<!-- <template>
    <div>
    <input type="number" v-model='number1' placeholder="0"/>
    <input type="number" v-model='number2' placeholder="0"/>
    <p>{{sumResult}}</p>
   </div>
</template>
<script>
export default {
    name: 'CalCulator',
    data() {
        return {
        number1: 0,
        number2: 0,
        result: ""
        }
    },
    computed: {
        sumResult() {
     return Number(this.number1) + Number(this.number2) 
    }}}
</script> -->
<template>
    <div>
      <div class="display">{{ expression }}</div>
      <form @submit.prevent="calculate">
        <div> 
          <button type="button" @click.stop="expression += '*'">*</button>
          <button type="button" @click.stop="expression += '/'">/</button>
          <button type="button" @click.stop="expression += '+'">+</button>
          <button type="button" @click.stop="expression += '-'">-</button>
        </div>
        <div>
          <button type="button" @click.stop="expression += '.'">.</button>
          <button type="button" @click.stop="expression += '9'">9</button>
          <button type="button" @click.stop="expression += '8'">8</button>
          <button type="button" @click.stop="expression += '7'">7</button>
        </div>
        <div>
          <button type="button" @click.stop="expression += '6'">6</button>
          <button type="button" @click.stop="expression += '5'">5</button>
          <button type="button" @click.stop="expression += '4'">4</button>
          <button type="button" @click.stop="expression += '3'">3</button>
        </div>
        <div>
          <button type="button" @click.stop="expression += '2'">2</button>
          <button type="button" @click.stop="expression += '1'">1</button>
          <button type="button" @click.stop="expression += '0'">0</button>
          <button type="submit">=</button>
        </div>
        <div>
          <button type="button" @click.stop="expression = ''">Clear</button>
        </div>
      </form>
    </div>
  </template>
  
  <script>
  import { evaluate } from "mathjs";
  
  export default {
    name: "App",
    data() {
      return {
        expression: "",
      };
    },
    methods: {
      calculate() {
        this.expression = evaluate(this.expression);
      },
    },
  };
  </script>
  
  <style scoped>
  button {
    width: 250px;
    height: 100px;
    background-color: rgb(132, 132, 132);
    font-size: large
  }

  .display {
    font-size: 30px;
    color: rgb(0, 0, 0);
    width: 100%;
    height: 100px;
    justify-content: center;
    display: flex;
  }
  
  #clear-button {
    width: 50px;
  }
  </style>