<template>
    <div>API</div>
    <div v-if="isLoad">Загрузка</div>
    <div v-else>
        <div v-for='(el, i) in teamData' :key="el.id">
        {{i + 1}}. {{el.abbreviation}} {{el.city}}
        <img src="https://w7.pngwing.com/pngs/743/331/png-transparent-sony-ericsson-xperia-pro-android-rooting-android-waste-containment-recycling-bin-waste-container.png"
        style="height: 30px; width: 30px"
        @click="removeItem(el.id)"
        />
        </div>
    </div>
</template>

<script>
export default {
    name: 'TestApi',
    data() {
        return {
        teamData: [],
        isLoad: true
        }
    },
    mounted(){
        const url = 'https://free-nba.p.rapidapi.com/teams?page=0';
const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '9eed21a35bmsh42bef84212330f9p1037b2jsn8b4efbab5dec',
		'X-RapidAPI-Host': 'free-nba.p.rapidapi.com'
	}
};

fetch(url, options)
.then(res => res.json())
.then(res => {
    this.teamData = res.data
    this.isLoad = false
})
    },
    methods: {
        removeItem(id){
            this.teamData = this.teamData.filter((el) => el.id !== id)
        }
    }
}
</script>