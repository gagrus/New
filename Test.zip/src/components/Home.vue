<template>
    <div>
        <div v-if="isAuth">
         <div>Добро пожаловать на мой сайт, {{userName}}</div>
         <button @click='logout'>Выйти</button>
        </div>

        <div v-else>
          <label>Ваше имя:</label>
          <input v-model="userName"/>
          <div>
          <label>Пароль:</label>
          <input v-model="passWord"/>
          <button @click="login">Сохранить</button>
        </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'HomePage',
    data(){
        return {
            isAuth: false,
            userName: '',
            passWord: '',
        }
    },
    methods: {
        login(){
            if(this.userName !== '', this.passWord !== '') {
                this.isAuth = true
                localStorage.setItem('isAuth', true)
                localStorage.setItem('userName', this.userName)
                localStorage.setItem('passWord',this.passWord)

                this.$router.push({
                    name: 'Chat',
                    query: {userName: this.userName, passWord: this.passWord}
                })
            } else {
                alert('Введите имя или пароль!')
            }
        },

        logout(){
            this.isAuth = false
            this.userName = ''
            localStorage.removeItem('isAuth')
            localStorage.removeItem('userName')
            localStorage.removeItem('passWord')
        }
    },
    created(){
        if(localStorage.getItem('isAuth')) {
            this.isAuth = true
            this.userName = localStorage.getItem('userName')
            this.passWord = localStorage.getItem('passWord')
        }
    },
}
</script>