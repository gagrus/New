<template>
 <div class="container">
  <NavComp/>
  <router-view></router-view>
 </div>
</template>

<script>
import NavComp from './components/Navigation.vue'

export default {
  name: 'App',
  components: {
    NavComp
  }
}
</script>

<style>
.container{
  background-color:dodgerblue;
  flex-direction: column;
  align-items: center;
  height: 1325px;
  font-family:Arial, Helvetica, sans-serif;
  display: flex;
}
</style>
